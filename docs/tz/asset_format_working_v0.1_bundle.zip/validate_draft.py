#!/usr/bin/env python3
"""Fixture-only demonstrator for a DRAFT schema; not a production/security-grade ZIP importer."""
import json, hashlib, sys, zipfile, re
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker
BASE=Path(__file__).parent
SCHEMA=json.loads((BASE/'manifest-1.0.draft.schema.json').read_text(encoding='utf-8'))
def strict_json(raw):
    def no_duplicate_pairs(pairs):
        d={}
        for k,v in pairs:
            if k in d: raise ValueError(f'duplicate JSON key: {k!r}')
            d[k]=v
        return d
    return json.loads(raw, object_pairs_hook=no_duplicate_pairs)
def validate_schema(doc):
    errors=list(Draft202012Validator(SCHEMA,format_checker=FormatChecker()).iter_errors(doc))
    if errors:raise ValueError('; '.join(f'{e.json_path}: {e.message}' for e in errors[:10]))
def semantic(doc):
    errs=[]
    def ids_unique(arr,path):
        names=[v['id'] for v in arr]
        if len(names)!=len(set(names)):errs.append(f'{path}: duplicate id')
        return set(names)
    files=ids_unique(doc['files'],'files');paths=[f['storage_path'] for f in doc['files']]
    if len(paths)!=len(set(paths)):errs.append('files: duplicate storage_path')
    for f in doc['files']:
        p=f['storage_path']
        if not p.startswith(('content/','generated/')):errs.append(f'files: invalid namespace {p}')
    groups=ids_unique(doc['groups'],'groups');sources=ids_unique(doc['origin']['sources'],'sources');inputids=ids_unique(doc['inputs'],'inputs')
    if len(set(inputids))!=len(doc['inputs']):errs.append('inputs duplicate')
    objects=[];entries=[]
    for i in doc['inputs']:
        for ref in i.get('source_refs',[]):
            if ref not in sources:errs.append(f'unknown source_ref: {ref}')
        obj_ids=ids_unique(i['objects'],f'inputs[{i["id"]}].objects');objects.extend(i['objects']);entries.extend(i['entries'])
        for e in i['entries']:
            if 'container_object_id' in e and e['container_object_id'] not in obj_ids:errs.append(f'unknown container object: {e["container_object_id"]}')
            result=e['result'];status=result['status']
            if status in ('included','included_renamed') and 'file_id' not in result:errs.append(f'input {i["id"]}: {status} without file_id')
            if status=='excluded' and not result.get('reason_code'):errs.append(f'input {i["id"]}: excluded without reason_code')
    ids_unique(entries,'input entries')
    for g in doc['groups']:
        if g.get('parent_id') is not None and g['parent_id'] not in groups:errs.append('group parent missing')
        for fid in g['file_refs']:
            if fid not in files:errs.append(f'group {g["id"]}: unknown file {fid}')
    parent={g['id']:g.get('parent_id') for g in doc['groups']}
    for start in groups:
        seen=set();cur=start
        while cur is not None:
            if cur in seen:errs.append(f'group cycle at {start}');break
            seen.add(cur);cur=parent.get(cur)
    previews=doc['previews'];pids=ids_unique(previews['items'],'previews')
    if previews.get('primary_id') is not None and previews['primary_id'] not in pids:errs.append('missing primary preview')
    for p in previews['items']:
        if p['file_id'] not in files:errs.append(f'preview {p["id"]}: missing file')
        for gid in p.get('group_refs',[]):
            if gid not in groups:errs.append(f'preview {p["id"]}: missing group {gid}')
    fielddefs=ids_unique(doc.get('field_definitions',[]),'field_definitions')
    for label,m in [('asset',doc['asset'].get('metadata',{}))]+[(f['id'],f.get('metadata',{})) for f in doc['files']]+[(g['id'],g.get('metadata',{})) for g in doc['groups']]:
        for item in m.get('custom_values',[]):
            if item['field_id'] not in fielddefs:errs.append(f'{label}: undefined field {item["field_id"]}')
    hist=doc['history']
    nums=[i['revision'] for i in hist]
    if nums!=sorted(set(nums)):errs.append('history revisions not strictly ordered')
    if nums[-1]!=doc['asset']['revision']:errs.append('history last revision != asset revision')
    return errs

def validate_zip(path):
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        if len(names)!=len(set(names)):raise ValueError('duplicate ZIP entry names')
        for n in names:
            comps=n.split('/')
            if n.startswith('/') or '\\' in n or ':' in n or any(c in ('.','..','') for c in comps):
                raise ValueError(f'unsafe ZIP name: {n}')
        if 'manifest.json' not in names:raise ValueError('missing manifest.json')
        doc=strict_json(z.read('manifest.json'))
        validate_schema(doc)
        errs=semantic(doc)
        for f in doc['files']:
            p=f['storage_path']
            if p not in names:errs.append(f'{p}: absent from ZIP');continue
            h=hashlib.sha256();nbytes=0
            with z.open(p) as stream:
                for chunk in iter(lambda:stream.read(1024*1024),b''):
                    h.update(chunk);nbytes+=len(chunk)
            if h.hexdigest()!=f['sha256']:errs.append(f'{p}: sha256 mismatch')
            if nbytes!=int(f['size_bytes']):errs.append(f'{p}: size mismatch')
        return errs
if __name__=='__main__':
    valid=json.loads((BASE/'manifest-v1.example.json').read_text(encoding='utf-8'))
    invalid=json.loads((BASE/'invalid_missing_file_ref.json').read_text(encoding='utf-8'))
    validate_schema(valid); assert semantic(valid)==[],semantic(valid)
    validate_schema(invalid); assert any('unknown file' in x for x in semantic(invalid))
    assert validate_zip(BASE/'fixture_asset.zip')==[]
    print('PASS: sample JSON Schema, semantic links, asset ZIP file hashes, negative missing-reference fixture')
    print('NOTE: draft only; security limits, storage transactions, compatibility and exhaustive validators not implemented.')
