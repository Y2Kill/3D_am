#!/usr/bin/env python3
"""Reproducible structural/diff audit of every locally available TZ revision.
Does not prove logical/semantic consistency; see the human-reviewed audit report.
"""
import difflib
import hashlib
import json
import re
from pathlib import Path
from datetime import date

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent


def version_key(p):
    m = re.search(r'_v(\d+)\.(\d+)\.md$', p.name)
    if not m:
        raise ValueError(p)
    return tuple(map(int,m.groups()))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    paths = sorted([p for p in ROOT.glob('TZ_catalog_3D_2D_draft_v*.md') if '(1)' not in p.name], key=version_key)
    assert len(paths) == 18, f'Expected 18 numbered revisions, got {len(paths)}'
    assert sha(ROOT/'TZ_catalog_3D_2D_draft_v0.1.md') == sha(ROOT/'TZ_catalog_3D_2D_draft_v0.1(1).md')
    report = {'date': str(date.today()), 'versions': [], 'transitions': [], 'duplicate': {
        'path': 'TZ_catalog_3D_2D_draft_v0.1(1).md',
        'same_bytes_as': 'TZ_catalog_3D_2D_draft_v0.1.md',
        'sha256': sha(ROOT/'TZ_catalog_3D_2D_draft_v0.1.md')
    }}
    for p in paths:
        text = p.read_text(encoding='utf8'); lines = text.splitlines()
        v='.'.join(map(str,version_key(p)))
        report['versions'].append({
            'file':p.name, 'version':v,
            'bytes': p.stat().st_size, 'lines':len(lines), 'sha256':sha(p),
            'h2_count':sum(x.startswith('## ') for x in lines),
            'h3_count':sum(x.startswith('### ') for x in lines),
            'approved_marks':text.count('[СОГЛАСОВАНО]'),
            'open_marks':text.count('[ОТКРЫТО]'),
            'proposal_marks':text.count('[ПРЕДЛОЖЕНИЕ]'),
            'code_fences_balanced':text.count('```')%2 == 0,
            'declared_version_matches_filename':bool(re.search(r'\*\*Версия:\*\*\s+'+re.escape(v)+r'(?:\s|$)',text)),
        })
    for p,q in zip(paths,paths[1:]):
        a=p.read_text(encoding='utf8').splitlines();b=q.read_text(encoding='utf8').splitlines()
        ops=difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes()
        hunks=[]
        for tag,i1,i2,j1,j2 in ops:
            if tag=='equal':continue
            old='\n'.join(a[i1:i2]);new='\n'.join(b[j1:j2])
            hunks.append({'kind':tag,'old_lines':[i1+1,i2], 'new_lines':[j1+1,j2],
                'old_excerpt':old[:300], 'new_excerpt':new[:300],
                'old_char_count':len(old),'new_char_count':len(new)})
        report['transitions'].append({
            'from':p.name,'to':q.name,
            'additions':sum(tag=='insert' for tag,*_ in ops),
            'replacements':sum(tag=='replace' for tag,*_ in ops),
            'deletions_of_nonblank_lines':sum(bool(''.join(a[i1:i2]).strip()) for tag,i1,i2,_,_ in ops if tag=='delete'),
            'replaced_old_lines':sum(i2-i1 for tag,i1,i2,_,_ in ops if tag=='replace'),
            'hunks':hunks
        })
    (OUT/'all_versions_diff_inventory.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    src=(ROOT/'TZ_catalog_3D_2D_draft_v1.7.md').read_text(encoding='utf8')
    newest=(ROOT/'TZ_catalog_3D_2D_draft_v1.8.md').read_text(encoding='utf8')
    # Match the complete old 1..17 content minus two updated cover metadata lines.
    prefix=src[:src.index('## 18. История изменений')]
    expected=prefix.replace('**Версия:** 1.7  ','**Версия:** 1.8  ',1)
    expected=expected.replace('**Основа:** `description.txt`, последующие уточнения требований в обсуждении, отчёт о сверке версий `docs/reports/01_TZ_evolution_loss_report.md`, сравнение v1.3–v1.5 с подготовленными решениями `docs/reports/03_TZ_v1.3-1.5_vs_prepared.md` и согласование нефункциональных требований §14.1–14.9.', '**Основа:** `description.txt`, эволюция ТЗ v0.1–v1.7, прежняя сверка П-1—П-6/С-1—С-2, согласование §14.1–14.9 и решения §19.1–19.4.19 (2026-11-06).',1)
    preservation=newest.startswith(expected)
    # Claimed agreed IDs all present in newest; not equivalent to schema verification.
    needed={
      'format_uuid':'urn:uuid:0d40b3a5-39ae-48e6-a8e8-da18b1b8c128',
      'history_compact':'compacted_ranges',
      'claims':'metadata.claims',
      'attachments':'AttachmentID',
      'historical':'historical_files',
      'bytes':'uint64',
      'P1_STL':'интерактивный просмотр STL',
      'P0':'P0.8',
    }
    checks={'original_sections_1_to_17_preserved_except_declared_cover_edits':preservation,
       **{k:(word in newest) for k,word in needed.items()}}
    (OUT/'structural_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('AUDIT:',len(paths),'versions; transitions:',len(report['transitions']))
    print('STRUCTURAL CHECKS:',json.dumps(checks,ensure_ascii=False))
    print('nonblank standalone deletion hunks:',sum(t['deletions_of_nonblank_lines'] for t in report['transitions']))
    if not all(checks.values()):raise SystemExit('One or more structural checks FAILED')
    if any(not all((v['code_fences_balanced'],v['declared_version_matches_filename'])) for v in report['versions']):
        raise SystemExit('Document metadata / code-fence validation FAILED')

if __name__=='__main__':main()
