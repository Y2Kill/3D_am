# Передача: R-01…R-09 и исходные материалы

**Начните с** `01_R01-R09_approved_handoff.md`.

Единственный новый нормативный материал в этом пакете — свод согласованных уточнений к проекту (но он пока НЕ применён к репозиторию). Остальные файлы — неизменённые снимки для анализа и сравнения. Формат ZIP-ассета 1.0 НЕ опубликован; ТЗ v1.8 и репозиторий `0e6825a` пока не модифицированы.

Сначала выполните этап A из документа (анализ без правок). Применение изменений и обновление статуса проекта — после утверждения плана владельцем.

## Файлы и SHA-256

- `01_R01-R09_approved_handoff.md` — `36cfb5cb95c251435b7ff4952f50583e0ed378efbfebaaa7eb271259a6822566`
- `references/TZ_catalog_3D_2D_draft_v1.8.md` — `14756cbb4d8a615b8e2798adafb02c432c7f4675e9ba83a993ce9f4252f4fb45`
- `references/05_TZ_v1.8_format_vs_prepared.md` — `baac4755b658f49ec6f4384eccce216dc0c3b0f65ac5ccfed8d55a3e54ccc393`
- `references/AUDIT_REPORT.md` — `59da278109a4ca377c2a183a3b1dab3f926865c99fe3f1d92eb5ca4cd28c0c56`
- `references/asset-format-consensus-v0.2.md` — `7f5043cfda33af5b3d274c4a8b1a3eb00627c67410d806a62836685b2ea2d51f`
- `references/3D_am_status_0e6825a.zip` — `6839f0b6a1da60ef2a9414da46171a4250b6a7bb10164be3f5a98f00a43eae70`
